package ten;
import java.util.*; // import Scanner and Math class


public class problem3 {
    public static void main(String[] args) {

        // create array of integers with size of 100
        int[] a = new int[100];

        // fill array with random integer values
        for (int i = 0; i < 100; i++) {
            // multiply value between 0.0 and 1.0 by 100 and add 1 to make more random
            a[i] = (int)(Math.random() * 100) + 1;
        }

        // create Scanner for taking input
		Scanner input = new Scanner(System.in);

		// asks for index of array
		System.out.print("Enter the index of the array: ");
		int index = input.nextInt();
        
        try {
			// print element at specified index
			System.out.println("The corresponding element value is " + 
				a[index]);
		}
		catch (ArrayIndexOutOfBoundsException ex) {
            // return out of bounds if outside of index range
			System.out.println("Out of Bounds");
		}
    }
}
