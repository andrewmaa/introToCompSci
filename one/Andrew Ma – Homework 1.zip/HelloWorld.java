/*  
intro to computer science 
jan. 29, 2024
andrew ma
warm up assignment: printing hello world in the terminal
*/

 // creating a new class
public class HelloWorld {
    public static void main (String [] args) {
        System.out.println("Hello World");
    }
}