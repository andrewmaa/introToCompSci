/*  
intro to computer science 
jan. 29, 2024
andrew ma
song lyrics assignment
*/
public class SongLyrics {
    public static void main (String [] args) {
        // song info:
        // the aisle from heaven knows
        // by pinkpantheress
        System.out.println(

            // using \\ for backslash usage
            // +// to combine multiple strings

            // title
            "\\\\ The aisle by PinkPantheress // \n \n"    +//
            // Using \t for chorus and \' to show single quote escape character usage
            
            // verse 1

            "It\'s one of those unfortunate things (things)\n" + //
            "That bad things always happen to me (to me)\n" + //
            "And you don\'t wanna keep the door open (open)\n" + //
            "You wanted to see me full of emotion\n" + //
            "I ruined all my friendships with you (with you)\n" + //
            "And I think I\'m runnin\' out of people to lose (to lose)\n" + //
            "I only have to give you my motion\n" + //
            "And you always find your way right back to me\n \n" + //
            
            "This problem again (this problem again)\n" + //
            "Look what I started (look what I started)\n" + //
            "I lay in your bed (I lay in your bed)\n" + //
            "That\'s how it started (that\'s how it started)\n" + //
            "A little bit more (a little bit more) of this mystery\n" + //
            "I will make you wish that you had never come to me (\'cause)\n");
        
        // chorus 
        System.out.println("\t I\'d picture you one day after you improved (look what I started)\n" + //
            "\t And you\'re walkin\' down the aisle (walkin\' down the aisle)\n" + //
            "\t It\'s the thing that makes me smile (that\'s how it started)\n" + //
            "\t You lay in bed, where you\'d rather be instead\n" + //
            "\t No, you\'re not quite stuck with me (you\'re not quite stuck with me)\n" + //
            "\t But, one day, you\'ll be\n");
        
    }
}
